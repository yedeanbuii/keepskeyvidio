Before using Lucifer, you need to install visual studio redistributables


x64: https://aka.ms/vs/17/release/vc_redist.x64.exe
x86: https://aka.ms/vs/17/release/vc_redist.x86.exe